class MapManager {
    constructor() {
        this.map = null;
        this.markers = new Map();
        this.userLocation = null;
        this.searchMarker = null;
        this.tempMarker = null;
        this.coordsDisplay = null;
        this.coordsLocked = false;
        this.lockedCoordinates = null;
        this.unlockButton = null;
    }

    async initialize() {
        try {
            this.map = L.map('map', {
                center: [20.5937, 78.9629],
                zoom: 4,
                attributionControl: true,
                doubleClickZoom: false
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 19
            }).addTo(this.map);

            this.coordsDisplay = L.control({ position: 'bottomleft' });
            this.coordsDisplay.onAdd = () => {
                const div = L.DomUtil.create('div', 'coordinate-display');
                div.innerHTML = 'Hover over the map';
                return div;
            };
            this.coordsDisplay.addTo(this.map);

            this.addGridLines();
            this.map.on('mousemove', this.onMouseMove.bind(this));
            this.map.on('click', this.handleMapClick.bind(this));
            this.map.on('dblclick', this.handleMapDoubleClick.bind(this));

            this.initializeSearch();
            this.initializeFilter();
            this.addUnlockControl();

            this.injectStyles();
        } catch (error) {
            console.error('Error initializing map:', error);
            throw error;
        }
    }

    injectStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .coordinate-display {
                background: white;
                padding: 10px;
                border-radius: 4px;
                box-shadow: 0 1px 5px rgba(0,0,0,0.4);
                font-size: 12px;
                line-height: 1.5;
            }
            .grid-label {
                font-size: 12px;
                color: #333;
                text-shadow: -1px -1px 0 #fff,
                            1px -1px 0 #fff,
                            -1px 1px 0 #fff,
                            1px 1px 0 #fff;
            }
            .temp-marker-dot.locked {
                width: 16px;
                height: 16px;
                background: red;
                border-radius: 50%;
                border: 2px solid white;
            }
        `;
        document.head.appendChild(style);
    }

    async getUserLocation() {
        return new Promise((resolve) => {
            if ("geolocation" in navigator) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        const { latitude, longitude } = position.coords;
                        this.userLocation = [latitude, longitude];

                        L.marker(this.userLocation, {
                            icon: L.divIcon({
                                className: 'user-location-marker',
                                html: '<div class="user-dot"></div>',
                                iconSize: [20, 20]
                            })
                        }).addTo(this.map);

                        resolve([latitude, longitude]);
                    },
                    (error) => {
                        console.warn('Error getting location:', error);
                        resolve(null);
                    }
                );
            } else {
                console.warn('Geolocation not supported');
                resolve(null);
            }
        });
    }

    initializeSearch() {
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.getElementById('searchBtn');

        const performSearch = async () => {
            const query = searchInput.value.trim();
            if (!query) return;

            try {
                const response = await fetch(`https://us1.locationiq.com/v1/search.php?key=${CONFIG.LOCATIONIQ_API_KEY}&q=${encodeURIComponent(query)}&format=json`);
                const data = await response.json();

                if (data && data[0]) {
                    const { lat, lon } = data[0];
                    this.map.setView([lat, lon], 13);

                    if (this.searchMarker) this.map.removeLayer(this.searchMarker);
                    this.searchMarker = L.marker([lat, lon]).addTo(this.map);
                }
            } catch (error) {
                console.error('Search error:', error);
                showNotification('Location search failed. Please try again.', 'error');
            }
        };

        searchBtn.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') performSearch();
        });
    }

    initializeFilter() {
        const filterSelect = document.getElementById('filterType');
        filterSelect.addEventListener('change', () => {
            const selectedType = filterSelect.value;
            this.filterMarkers(selectedType);
        });
    }

    filterMarkers(type) {
        this.markers.forEach((marker, id) => {
            if (type === 'all' ||
                (type === 'active' && marker.status === 'active') ||
                (type === 'resolved' && marker.status === 'resolved') ||
                marker.disasterType === type) {
                marker.leafletMarker.addTo(this.map);
            } else {
                this.map.removeLayer(marker.leafletMarker);
            }
        });
    }

    addGridLines() {
        for (let i = -180; i <= 180; i += 20) {
            L.polyline([[90, i], [-90, i]], {
                color: '#999',
                weight: 1,
                opacity: 0.5
            }).addTo(this.map);

            if (i !== 180) {
                L.marker([0, i], {
                    icon: L.divIcon({
                        className: 'grid-label',
                        html: `${Math.abs(i)}°${i < 0 ? 'W' : 'E'}`,
                        iconSize: [50, 20]
                    })
                }).addTo(this.map);
            }
        }

        for (let i = -80; i <= 80; i += 20) {
            L.polyline([[i, -180], [i, 180]], {
                color: '#999',
                weight: 1,
                opacity: 0.5
            }).addTo(this.map);

            L.marker([i, 0], {
                icon: L.divIcon({
                    className: 'grid-label',
                    html: `${Math.abs(i)}°${i < 0 ? 'S' : 'N'}`,
                    iconSize: [50, 20]
                })
            }).addTo(this.map);
        }
    }

    onMouseMove(e) {
        const { lat, lng } = e.latlng;
        const displayDiv = document.querySelector('.coordinate-display');

        if (displayDiv) {
            displayDiv.innerHTML = `
                <strong>Mouse Position</strong><br>
                Lat: ${lat.toFixed(6)}°<br>
                Lng: ${lng.toFixed(6)}°
            `;
        }

        if (!this.coordsLocked) {
            this.updateCoordinateFields(lat, lng);
        } else if (this.lockedCoordinates) {
            this.updateCoordinateFields(this.lockedCoordinates.lat, this.lockedCoordinates.lng);
        }
    }

    updateCoordinateFields(lat, lng) {
        const latInput = document.getElementById('latitude');
        const lonInput = document.getElementById('longitude');

        if (latInput && lonInput) {
            latInput.value = lat.toFixed(6);
            lonInput.value = lng.toFixed(6);
        }
    }

    addUnlockControl() {
        const UnlockControl = L.Control.extend({
            options: { position: 'topright' },
            onAdd: () => {
                const container = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
                const button = L.DomUtil.create('a', 'unlock-coordinates', container);
                button.innerHTML = '🔓';
                button.title = 'Unlock coordinates';
                button.href = '#';
                button.style.display = 'none';

                L.DomEvent.on(button, 'click', (e) => {
                    L.DomEvent.preventDefault(e);
                    this.unlockCoordinates();
                });

                this.unlockButton = button;
                return container;
            }
        });

        this.map.addControl(new UnlockControl());
    }

    unlockCoordinates() {
        this.coordsLocked = false;
        if (this.unlockButton) {
            this.unlockButton.style.display = 'none';
        }

        const latInput = document.getElementById('latitude');
        const lonInput = document.getElementById('longitude');
        if (latInput && lonInput) {
            latInput.removeAttribute('readonly');
            lonInput.removeAttribute('readonly');
        }

        if (typeof showNotification === 'function') {
            showNotification('Coordinates unlocked', 'info');
        }
    }

    handleMapDoubleClick(e) {
        e.originalEvent.preventDefault();
        e.originalEvent.stopPropagation();

        const { lat, lng } = e.latlng;
        this.lockedCoordinates = { lat, lng };
        this.coordsLocked = true;

        this.updateCoordinateFields(lat, lng);

        if (this.tempMarker) this.map.removeLayer(this.tempMarker);

        this.tempMarker = L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'temp-marker locked',
                html: '<div class="temp-marker-dot locked"></div>',
                iconSize: [20, 20]
            })
        }).addTo(this.map);

        this.tempMarker.bindPopup(`
            <strong>Locked Location</strong><br>
            Latitude: ${lat.toFixed(6)}°<br>
            Longitude: ${lng.toFixed(6)}°
        `).openPopup();

        const latInput = document.getElementById('latitude');
        const lonInput = document.getElementById('longitude');
        if (latInput && lonInput) {
            latInput.setAttribute('readonly', true);
            lonInput.setAttribute('readonly', true);
        }

        if (this.unlockButton) this.unlockButton.style.display = 'block';

        if (typeof showNotification === 'function') {
            showNotification('Location coordinates locked', 'success');
        }
    }

    handleMapClick(e) {
        // You can add single-click behavior if needed
        // Currently it's just reserved for future use
    }

    addDisasterMarker(report) {
        const { id, latitude, longitude, type, severity, description, timestamp, status } = report;
        
        // Create marker with custom icon based on severity and status
        const markerIcon = L.divIcon({
            className: `disaster-marker ${severity} ${status}`,
            html: `<div class="marker-dot ${severity} ${status}"></div>`,
            iconSize: [20, 20]
        });

        const marker = L.marker([latitude, longitude], { icon: markerIcon });
        
        // Add popup with report details
        const popupContent = `
            <div class="marker-popup">
                <h3>${this.capitalizeFirstLetter(type)}</h3>
                <p>${description}</p>
                <p class="report-meta">Severity: ${this.capitalizeFirstLetter(severity)}</p>
                <p class="report-meta">Status: ${this.capitalizeFirstLetter(status)}</p>
                <p class="report-meta">Reported: ${new Date(timestamp).toLocaleString()}</p>
                <div class="contact-info">
                    <p>Emergency Contact: ${report.contactPhone}</p>
                </div>
            </div>
        `;
        
        marker.bindPopup(popupContent);
        marker.addTo(this.map);

        // Store marker reference
        this.markers.set(id, {
            leafletMarker: marker,
            disasterType: type,
            severity: severity,
            status: status
        });

        // Check if this is a new report near the user
        if (this.userLocation) {
            const distance = this.calculateDistance(
                this.userLocation[0], this.userLocation[1],
                latitude, longitude
            );
            
            if (distance <= CONFIG.NOTIFICATION_RADIUS) {
                showNotification(
                    `New ${type} report ${Math.round(distance/1000)}km from your location`,
                    severity
                );
            }
        }
    }

    updateMarkerStatus(id, status) {
        const marker = this.markers.get(id);
        if (marker) {
            // Update marker status
            marker.status = status;
            
            // Update marker icon
            const newIcon = L.divIcon({
                className: `disaster-marker ${marker.severity} ${status}`,
                html: `<div class="marker-dot ${marker.severity} ${status}"></div>`,
                iconSize: [20, 20]
            });
            
            marker.leafletMarker.setIcon(newIcon);
            
            // Update popup content
            const popup = marker.leafletMarker.getPopup();
            if (popup) {
                const content = popup.getContent();
                const updatedContent = content.replace(
                    /Status: \w+/,
                    `Status: ${this.capitalizeFirstLetter(status)}`
                );
                popup.setContent(updatedContent);
            }
        }
    }

    removeDisasterMarker(id) {
        const marker = this.markers.get(id);
        if (marker) {
            this.map.removeLayer(marker.leafletMarker);
            this.markers.delete(id);
        }
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371e3; // Earth's radius in meters
        const φ1 = lat1 * Math.PI/180;
        const φ2 = lat2 * Math.PI/180;
        const Δφ = (lat2-lat1) * Math.PI/180;
        const Δλ = (lon2-lon1) * Math.PI/180;

        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        return R * c; // Distance in meters
    }

    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
}

// Initialize map manager
let mapManager;
document.addEventListener('DOMContentLoaded', async () => {
    mapManager = new MapManager();
    try {
        await mapManager.initialize();
    } catch (error) {
        console.error('Failed to initialize map:', error);
        showNotification('Failed to initialize map. Please refresh the page.', 'error');
    }
}); 