class NotificationManager {
    constructor() {
        this.hasPermission = false;
        this.initialize();
    }

    async initialize() {
        if ('Notification' in window) {
            const permission = await Notification.requestPermission();
            this.hasPermission = permission === 'granted';
        }
    }

    async sendBrowserNotification(title, options = {}) {
        if (!this.hasPermission) return;

        try {
            const notification = new Notification(title, {
                icon: '/images/alert-icon.png',
                ...options
            });

            notification.onclick = () => {
                window.focus();
                notification.close();
            };
        } catch (error) {
            console.error('Error sending notification:', error);
        }
    }

    notifyDisasterAlert(severity, details) {
        const severityEmoji = {
            danger: '🔴',
            moderate: '🟡',
            safe: '🟢'
        };

        const title = `${severityEmoji[severity]} Disaster Alert`;
        const options = {
            body: `Severity: ${severity.toUpperCase()}\n${details}`,
            vibrate: [200, 100, 200],
            tag: 'disaster-alert',
            renotify: true
        };

        return this.sendBrowserNotification(title, options);
    }

    notifyEmergencyServices(services) {
        const title = '🚨 Emergency Services Found';
        const body = services.map(service => 
            `${service.type === 'hospital' ? '🏥' : service.type === 'fire_station' ? '🚒' : '👮'} ${service.name}`
        ).join('\n');

        const options = {
            body: body,
            tag: 'emergency-services',
            renotify: false
        };

        return this.sendBrowserNotification(title, options);
    }
}

// UI Notification function
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    // Trigger animation
    setTimeout(() => notification.classList.add('show'), 10);

    // Remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Initialize notification manager
let notificationManager;
document.addEventListener('DOMContentLoaded', () => {
    notificationManager = new NotificationManager();
}); 