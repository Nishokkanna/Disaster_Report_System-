class DisasterReportingApp {
    constructor() {
        this.reports = new Map();
        this.selectedLocation = null;
        this.loadReportsFromStorage();
        this.initializeEventListeners();
    }

    initialize() {
        this.displayRecentReports();
    }

    initializeEventListeners() {
        const reportBtn = document.getElementById('reportBtn');
        const filterSelect = document.getElementById('filterType');
        const latitudeInput = document.getElementById('latitude');
        const longitudeInput = document.getElementById('longitude');

        reportBtn.addEventListener('click', () => this.submitReport());

        // Add coordinate validation
        latitudeInput.addEventListener('change', () => {
            const value = parseFloat(latitudeInput.value);
            if (value < -90 || value > 90) {
                showNotification('Latitude must be between -90 and 90 degrees', 'error');
                latitudeInput.value = '';
            }
        });

        longitudeInput.addEventListener('change', () => {
            const value = parseFloat(longitudeInput.value);
            if (value < -180 || value > 180) {
                showNotification('Longitude must be between -180 and 180 degrees', 'error');
                longitudeInput.value = '';
            }
        });

        // Filter reports
        filterSelect.addEventListener('change', () => {
            this.filterReports(filterSelect.value);
        });

        // Clean up old reports every hour
        setInterval(() => this.cleanupOldReports(), 3600000);
    }

    async submitReport() {
        const type = document.getElementById('disasterType').value;
        const description = document.getElementById('description').value;
        const severity = document.querySelector('input[name="severity"]:checked')?.value;
        const contactPhone = document.getElementById('contactPhone').value;
        const address = document.getElementById('address').value;
        const district = document.getElementById('district').value;
        const latitude = document.getElementById('latitude').value;
        const longitude = document.getElementById('longitude').value;

        if (!type || !description || !severity || !contactPhone || !address || !district) {
            showNotification('Please fill in all required fields', 'error');
            return;
        }

        // Validate phone number format
        const phoneRegex = /^[\d\s\-+()]{10,}$/;
        if (!phoneRegex.test(contactPhone)) {
            showNotification('Please enter a valid phone number', 'error');
            return;
        }

        // Validate coordinates if provided
        let lat = null;
        let lon = null;
        if (latitude || longitude) {
            if (!latitude || !longitude) {
                showNotification('Please provide both latitude and longitude, or leave both empty', 'error');
                return;
            }
            lat = parseFloat(latitude);
            lon = parseFloat(longitude);
            if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
                showNotification('Please enter valid coordinates', 'error');
                return;
            }
        }

        try {
            const report = {
                id: Date.now().toString(),
                type: type,
                description: description,
                severity: severity,
                latitude: lat,
                longitude: lon,
                address: address,
                district: district,
                contactPhone: contactPhone,
                timestamp: new Date().toISOString(),
                status: 'active'
            };

            // Add report to storage and map
            this.addReport(report);

            // Clear form
            document.getElementById('disasterType').value = '';
            document.getElementById('description').value = '';
            document.querySelector('input[name="severity"]:checked').checked = false;
            document.getElementById('address').value = '';
            document.getElementById('district').value = '';
            document.getElementById('latitude').value = '';
            document.getElementById('longitude').value = '';
            document.getElementById('contactPhone').value = '';

            showNotification('Report submitted successfully', 'success');
        } catch (error) {
            console.error('Error submitting report:', error);
            showNotification('Failed to submit report. Please try again.', 'error');
        }
    }

    getCurrentLocation() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation is not supported by your browser'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => resolve(position.coords),
                (error) => reject(error)
            );
        });
    }

    addReport(report) {
        // Add to memory
        this.reports.set(report.id, report);

        // Add to localStorage
        this.saveReportsToStorage();

        // Add marker to map if coordinates are provided
        if (report.latitude !== null && report.longitude !== null) {
            mapManager.addDisasterMarker(report);
            // Center map on the new report
            mapManager.map.setView([report.latitude, report.longitude], 15);
        }

        // Update recent reports display
        this.displayRecentReports();

        // Send notification if browser supports it
        if (notificationManager.hasPermission) {
            notificationManager.sendBrowserNotification(
                'New Disaster Report',
                {
                    body: `${report.type} reported near ${report.latitude?.toFixed(4) || ''} ${report.longitude?.toFixed(4) || ''}`,
                    tag: report.id
                }
            );
        }
    }

    loadReportsFromStorage() {
        try {
            const stored = localStorage.getItem('disasterReports');
            if (stored) {
                const reports = JSON.parse(stored);
                reports.forEach(report => this.reports.set(report.id, report));
            }
        } catch (error) {
            console.error('Error loading reports from storage:', error);
            showNotification('Error loading saved reports', 'error');
        }
    }

    saveReportsToStorage() {
        try {
            const reportsArray = Array.from(this.reports.values());
            localStorage.setItem('disasterReports', JSON.stringify(reportsArray));
        } catch (error) {
            console.error('Error saving reports to storage:', error);
            showNotification('Error saving report', 'error');
        }
    }

    displayRecentReports() {
        const recentReportsContainer = document.getElementById('recentReports');
        recentReportsContainer.innerHTML = '';

        // Sort reports by timestamp (most recent first)
        const sortedReports = Array.from(this.reports.values())
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        sortedReports.forEach(report => {
            const reportElement = document.createElement('div');
            reportElement.className = `report-card ${report.severity} ${report.status}`;
            
            const timeAgo = this.getTimeAgo(new Date(report.timestamp));
            
            reportElement.innerHTML = `
                <h3>${this.capitalizeFirstLetter(report.type)}</h3>
                <p>${report.description}</p>
                <div class="location-info">
                    <p class="report-meta">Address: ${report.address}</p>
                    <p class="report-meta">District: ${report.district}</p>
                    ${report.latitude !== null ? 
                        `<p class="report-meta">Coordinates: ${report.latitude}, ${report.longitude}</p>` : 
                        ''
                    }
                </div>
                <p class="report-meta">Severity: ${this.capitalizeFirstLetter(report.severity)}</p>
                <p class="report-meta">Reported: ${timeAgo}</p>
                <div class="contact-details">
                    <p>Emergency Contact: ${report.contactPhone}</p>
                </div>
                <div class="report-actions">
                    ${report.status === 'active' ? 
                        `<button class="resolve-btn" data-id="${report.id}">Mark as Resolved</button>` : 
                        `<p class="report-meta">Resolved: ${this.getTimeAgo(new Date(report.resolvedAt))}</p>`
                    }
                    <button class="delete-btn" data-id="${report.id}">Delete Report</button>
                </div>
            `;

            // Add event listeners
            const resolveBtn = reportElement.querySelector('.resolve-btn');
            if (resolveBtn) {
                resolveBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.resolveReport(report.id);
                });
            }

            const deleteBtn = reportElement.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.deleteReport(report.id);
            });

            // Only add map centering if coordinates are available
            if (report.latitude !== null && report.longitude !== null) {
                reportElement.addEventListener('click', () => {
                    mapManager.map.setView([report.latitude, report.longitude], 15);
                });
            }

            recentReportsContainer.appendChild(reportElement);
        });
    }

    cleanupOldReports() {
        const now = new Date();
        const TWO_DAYS = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds

        let hasChanges = false;
        this.reports.forEach((report, id) => {
            const reportTime = new Date(report.timestamp);
            if (now - reportTime > TWO_DAYS) {
                this.reports.delete(id);
                mapManager.removeDisasterMarker(id);
                hasChanges = true;
            }
        });

        if (hasChanges) {
            this.saveReportsToStorage();
            this.displayRecentReports();
        }
    }

    getTimeAgo(date) {
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) return 'just now';
        
        const diffInMinutes = Math.floor(diffInSeconds / 60);
        if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
        
        const diffInHours = Math.floor(diffInMinutes / 60);
        if (diffInHours < 24) return `${diffInHours}h ago`;
        
        const diffInDays = Math.floor(diffInHours / 24);
        return `${diffInDays}d ago`;
    }

    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    resolveReport(id) {
        const report = this.reports.get(id);
        if (report) {
            report.status = 'resolved';
            report.resolvedAt = new Date().toISOString();
            
            // Update storage
            this.saveReportsToStorage();
            
            // Update map marker
            mapManager.updateMarkerStatus(id, 'resolved');
            
            // Update display
            this.displayRecentReports();
            
            showNotification('Report marked as resolved', 'success');
        }
    }

    deleteReport(id) {
        if (this.reports.has(id)) {
            // Remove from map
            mapManager.removeDisasterMarker(id);
            
            // Remove from memory
            this.reports.delete(id);
            
            // Update storage
            this.saveReportsToStorage();
            
            // Update display
            this.displayRecentReports();
            
            showNotification('Report deleted', 'success');
        }
    }

    filterReports(filter) {
        const reportsContainer = document.getElementById('recentReports');
        reportsContainer.innerHTML = '';

        const filteredReports = Array.from(this.reports.values()).filter(report => {
            if (filter === 'all') return true;
            if (filter === 'active') return report.status === 'active';
            if (filter === 'resolved') return report.status === 'resolved';
            return report.type === filter || report.district.toLowerCase().includes(filter.toLowerCase());
        });

        // Sort reports by timestamp (most recent first)
        filteredReports.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

        filteredReports.forEach(report => this.createReportCard(report));
    }

    createReportCard(report) {
        const reportsContainer = document.getElementById('recentReports');
        const reportElement = document.createElement('div');
        reportElement.className = `report-card ${report.severity} ${report.status}`;
        
        const timeAgo = this.getTimeAgo(new Date(report.timestamp));
        
        reportElement.innerHTML = `
            <h3>${this.capitalizeFirstLetter(report.type)}</h3>
            <p>${report.description}</p>
            <div class="location-info">
                <p class="report-meta">Address: ${report.address}</p>
                <p class="report-meta">District: ${report.district}</p>
                ${report.latitude !== null ? 
                    `<p class="report-meta">Coordinates: ${report.latitude}, ${report.longitude}</p>` : 
                    ''
                }
            </div>
            <p class="report-meta">Severity: ${this.capitalizeFirstLetter(report.severity)}</p>
            <p class="report-meta">Reported: ${timeAgo}</p>
            <div class="contact-details">
                <p>Emergency Contact: ${report.contactPhone}</p>
            </div>
            <div class="report-actions">
                ${report.status === 'active' ? 
                    `<button class="resolve-btn" data-id="${report.id}">Mark as Resolved</button>` : 
                    `<p class="report-meta">Resolved: ${this.getTimeAgo(new Date(report.resolvedAt))}</p>`
                }
                <button class="delete-btn" data-id="${report.id}">Delete Report</button>
            </div>
        `;

        // Add event listeners
        const resolveBtn = reportElement.querySelector('.resolve-btn');
        if (resolveBtn) {
            resolveBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.resolveReport(report.id);
            });
        }

        const deleteBtn = reportElement.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.deleteReport(report.id);
        });

        // Only add map centering if coordinates are available
        if (report.latitude !== null && report.longitude !== null) {
            reportElement.addEventListener('click', () => {
                mapManager.map.setView([report.latitude, report.longitude], 15);
            });
        }

        reportsContainer.appendChild(reportElement);
    }
}

// Initialize application
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new DisasterReportingApp();
    app.initialize();
}); 