const CONFIG = {
    LOCATIONIQ_API_KEY: 'pk.b1acd1fa14f8ca1d097ad21a8a227d1f', // Your LocationIQ API key
    NOTIFICATION_RADIUS: 5000, // 5km radius for nearby alerts
    MAP_DEFAULT_CENTER: [0, 0],
    MAP_DEFAULT_ZOOM: 2
}; 